dofile(getDataDir() .. 'global/greeting.lua')

local keywordHandler = KeywordHandler:new()
local npcHandler = NpcHandler:new(keywordHandler)
NpcSystem.parseParameters(npcHandler)



-- OTServ event handling functions start
function onCreatureAppear(cid)				npcHandler:onCreatureAppear(cid) end
function onCreatureDisappear(cid) 			npcHandler:onCreatureDisappear(cid) end
function onCreatureSay(cid, type, msg) 	npcHandler:onCreatureSay(cid, type, msg) end
function onThink() 						npcHandler:onThink() end

function greetCallback(cid)
	if getPlayerSex(cid) == 1 then
	npcHandler:setMessage(MESSAGE_GREET, "Greetings, young man. Looking for a passage or some fish, ".. getPlayerName(cid) .."?")
	return true
	else
	npcHandler:setMessage(MESSAGE_GREET, "Greetings, young lady. Looking for a passage or some fish, ".. getPlayerName(cid) .."?")
	return true
	end	
end	
npcHandler:setCallback(CALLBACK_GREET, greetCallback)

local shopModule = ShopModule:new()
npcHandler:addModule(shopModule)
shopModule:addBuyableItem({'fish'}, 					Cffish, 5)

keywordHandler:addKeyword({'name'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My name is Pemaret, the fisherman."})
keywordHandler:addKeyword({'job'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm a fisherman and I take along people to Edron. You can also buy some fresh fish."})
keywordHandler:addKeyword({'tibia'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I love to sail on the seas of Tibia."})
keywordHandler:addKeyword({'sea'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I love to sail on the seas of Tibia."})
keywordHandler:addKeyword({'cormaya'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "It's a lovely and peaceful isle. Did you already visit the nice sandy beach?"})
keywordHandler:addKeyword({'isle'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "It's a lovely and peaceful isle. Did you already visit the nice sandy beach?"})
keywordHandler:addKeyword({'beach'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "There is a nice sandy beach in the west of Cormaya."})
keywordHandler:addKeyword({'ship'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My boat is ready to bring you to Edron."})
keywordHandler:addKeyword({'boat'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My boat is ready to bring you to Edron."})
keywordHandler:addKeyword({'passage'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My boat is ready to bring you to Edron."})


function creatureSayCallback(cid, type, msg) msg = string.lower(msg)
pos = getPlayerPosition(cid)

	if(npcHandler.busyState ~= 0) and (npcHandler.focus ~= cid) then
		--Travel in hurry--
		if msgcontains(msg, "bring me to edron") then
			Permaretbcprice = 20
			Permaretbcdestination = Boatedron
			bcname = "Edron"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, Permaretbcprice) == TRUE then
				doTeleportThing(cid, Permaretbcdestination)
				doSendMagicEffect(Permaretbcdestination, 10)
				npcHandler:say("Here we go!", 1)
				permaret_talk_state = 0
				else
				npcHandler:say("You don't have enough money.", 1)
				permaret_talk_state = 0
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			permaret_talk_state = 0	
			end
		elseif msgcontains(msg, "bring me to eremo") then
			Permaretbcprice = 0
			Permaretbcdestination = Boateremo
			bcname = "Eremo"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, Permaretbcprice) == TRUE then
				doTeleportThing(cid, Permaretbcdestination)
				doSendMagicEffect(Permaretbcdestination, 10)
				npcHandler:say("Here we go!", 1)
				permaret_talk_state = 0
				else
				npcHandler:say("You don't have enough money.", 1)
				permaret_talk_state = 0
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			permaret_talk_state = 0	
			end
		--End of Travel in hurry--
		end
		return false
	end
	
	if(npcHandler.focus ~= cid) then
		return false
	end
	
--Give Destination--
if msgcontains(msg, 'edron') and npcHandler.focus == cid then
	Permaretbcprice = 20
	Permaretbcdestination = Boatedron
	bcname = "Edron"
	npcHandler:say("Do you want to get to Edron for ".. Permaretbcprice .." gold?", 1)
	permaret_talk_state = 94987
	
elseif msgcontains(msg, "eremo") and npcHandler.focus == cid then
	Permaretbcprice = 0
	Permaretbcdestination = Boateremo
	bcname = ""
	npcHandler:say("Oh, you know the good old sage Eremo. I can bring you to his little island. Do you want me to do that?", 1)
	permaret_talk_state = 94987

--End of Give Destination--
	

	
	
--System that does the job after confirm destination--
elseif permaret_talk_state == 94987 and msgcontains(msg, 'yes') and npcHandler.focus == cid then
	if (getTilePzInfo(pos) == FALSE) then
		if doPlayerRemoveMoney(cid, Permaretbcprice) == TRUE then
		doTeleportThing(cid, Permaretbcdestination)
		doSendMagicEffect(Permaretbcdestination, 10)
		npcHandler:say("Here we go!", 1)
		permaret_talk_state = 0
		else
		npcHandler:say("You don't have enough money.", 1)
		permaret_talk_state = 0
		end
	else
	npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
	permaret_talk_state = 0	
	end
--End of the System that does the job after confirm destination--
	
	
end		
    return 1
end


npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback)
npcHandler:addModule(FocusModule:new())
