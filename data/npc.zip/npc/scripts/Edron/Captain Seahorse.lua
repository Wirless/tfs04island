dofile(getDataDir() .. 'global/greeting.lua')

local keywordHandler = KeywordHandler:new()
local npcHandler = NpcHandler:new(keywordHandler)
NpcSystem.parseParameters(npcHandler)



-- OTServ event handling functions start
function onCreatureAppear(cid)				npcHandler:onCreatureAppear(cid) end
function onCreatureDisappear(cid) 			npcHandler:onCreatureDisappear(cid) end
function onCreatureSay(cid, type, msg) 	npcHandler:onCreatureSay(cid, type, msg) end
function onThink() 						npcHandler:onThink() end

function greetCallback(cid)
	if getPlayerSex(cid) == 1 then
	npcHandler:setMessage(MESSAGE_GREET, "Welcome on board, Sir ".. getPlayerName(cid) ..".")
	return true
	else
	npcHandler:setMessage(MESSAGE_GREET, "Welcome on board, Madam ".. getPlayerName(cid) ..".")
	return true
	end	
end	
npcHandler:setCallback(CALLBACK_GREET, greetCallback)

local shopModule = ShopModule:new()
npcHandler:addModule(shopModule)
 

keywordHandler:addKeyword({'name'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My name is Captain Seahorse from the Royal Tibia Line."})
keywordHandler:addKeyword({'job'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I am the captain of this sailing-ship."})
keywordHandler:addKeyword({'captain'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I am the captain of this sailing-ship."})
keywordHandler:addKeyword({'ship'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "The Royal Tibia Line connects all seaside towns of Tibia."})
keywordHandler:addKeyword({'line'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "The Royal Tibia Line connects all seaside towns of Tibia."})
keywordHandler:addKeyword({'company'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "The Royal Tibia Line connects all seaside towns of Tibia."})
keywordHandler:addKeyword({'route'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "The Royal Tibia Line connects all seaside towns of Tibia."})
keywordHandler:addKeyword({'tibia'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "The Royal Tibia Line connects all seaside towns of Tibia."})
keywordHandler:addKeyword({'good'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "We can transport everything you want."})
keywordHandler:addKeyword({'passanger'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "We would like to welcome you on board."})
keywordHandler:addKeyword({'trip'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Thais, Carlin, Ab'Dendriel, Venore, Ankrahmun, Port Hope or the isle Cormaya?"})
keywordHandler:addKeyword({'passage'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Thais, Carlin, Ab'Dendriel, Venore, Ankrahmun, Port Hope or the isle Cormaya?"})
keywordHandler:addKeyword({'town'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Thais, Carlin, Ab'Dendriel, Venore, Ankrahmun, Port Hope or the isle Cormaya?"})
keywordHandler:addKeyword({'destination'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Thais, Carlin, Ab'Dendriel, Venore, Ankrahmun, Port Hope or the isle Cormaya?"})
keywordHandler:addKeyword({'sail'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Thais, Carlin, Ab'Dendriel, Venore, Ankrahmun, Port Hope or the isle Cormaya?"})
keywordHandler:addKeyword({'go'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Thais, Carlin, Ab'Dendriel, Venore, Ankrahmun, Port Hope or the isle Cormaya?"})
keywordHandler:addKeyword({'ice'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm sorry, but we don't serve the routes to the Ice Islands."})
keywordHandler:addKeyword({'senja'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm sorry, but we don't serve the routes to the Ice Islands."})
keywordHandler:addKeyword({'folda'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm sorry, but we don't serve the routes to the Ice Islands."})
keywordHandler:addKeyword({'vega'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm sorry, but we don't serve the routes to the Ice Islands."})
keywordHandler:addKeyword({'darashia'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm not sailing there. This route is afflicted by a ghost ship! However I've heard that Captain Fearless from Venore sails there."})
keywordHandler:addKeyword({'darama'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm not sailing there. This route is afflicted by a ghost ship! However I've heard that Captain Fearless from Venore sails there."})
keywordHandler:addKeyword({'ghost'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Many people who sailed to Darashia never returned because they were attacked by a ghostship! I'll never sail there!"})
keywordHandler:addKeyword({'edron'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "This is Edron. Where do you want to go?"})

function creatureSayCallback(cid, type, msg) msg = string.lower(msg)
pos = getPlayerPosition(cid)
	if(npcHandler.busyState ~= 0) and (npcHandler.focus ~= cid) then
		--Travel in hurry--
		if msgcontains(msg, "bring me to carlin") then
			CapSeahorsebcprice = 110
			CapSeahorsebcdestination = Boatcarlin
			bcname = "Carlin"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
				doTeleportThing(cid, CapSeahorsebcdestination)
				doSendMagicEffect(CapSeahorsebcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to thais") then
			CapSeahorsebcprice = 160
			CapSeahorsebcdestination = Boatthais
			bcname = "Thais"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
				doTeleportThing(cid, CapSeahorsebcdestination)
				doSendMagicEffect(CapSeahorsebcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to ab'dendriel") then
			CapSeahorsebcprice = 70
			CapSeahorsebcdestination = Boatabdendriel
			bcname = "Ab'Dendriel"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
				doTeleportThing(cid, CapSeahorsebcdestination)
				doSendMagicEffect(CapSeahorsebcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to cormaya") then
			CapSeahorsebcprice = 20
			CapSeahorsebcdestination = Boatcormaya
			bcname = "Cormaya"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
				doTeleportThing(cid, CapSeahorsebcdestination)
				doSendMagicEffect(CapSeahorsebcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to venore") then
			CapSeahorsebcprice = 40
			CapSeahorsebcdestination = Boatvenore
			bcname = "Venore"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
				doTeleportThing(cid, CapSeahorsebcdestination)
				doSendMagicEffect(CapSeahorsebcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to ankrahmun") then
			CapSeahorsebcprice = 160
			CapSeahorsebcdestination = Boatankrahmun
			bcname = "Ankrahmun"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
				doTeleportThing(cid, CapSeahorsebcdestination)
				doSendMagicEffect(CapSeahorsebcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to port hope") then
			CapSeahorsebcprice = 150
			CapSeahorsebcdestination = Boatporthope
			bcname = "Port Hope"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
				doTeleportThing(cid, CapSeahorsebcdestination)
				doSendMagicEffect(CapSeahorsebcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		--End of Travel in hurry--
		end
	end
	
	if(npcHandler.focus ~= cid) then
		return false
	end
	
--Give Destination--
if msgcontains(msg, 'thais') and npcHandler.focus == cid then
	CapSeahorsebcprice = 160
	CapSeahorsebcdestination = Boatthais
	bcname = "Thais"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSeahorsebcprice .." gold?", 1)
	TalkState(cid, 94990)
	
elseif msgcontains(msg, 'carlin') and npcHandler.focus == cid then
	CapSeahorsebcprice = 110
	CapSeahorsebcdestination = Boatcarlin
	bcname = "Carlin"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSeahorsebcprice .." gold?", 1)
	TalkState(cid, 94990)

elseif msgcontains(msg, "ab'dendriel") and npcHandler.focus == cid then
	CapSeahorsebcprice = 70
	CapSeahorsebcdestination = Boatabdendriel
	bcname = "Ab'Dendriel"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSeahorsebcprice .." gold?", 1)
	TalkState(cid, 94990)
	
elseif msgcontains(msg, "cormaya") and npcHandler.focus == cid then
	CapSeahorsebcprice = 20
	CapSeahorsebcdestination = Boatcormaya
	bcname = "Cormaya"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSeahorsebcprice .." gold?", 1)
	TalkState(cid, 94990)	
	
elseif msgcontains(msg, "venore") and npcHandler.focus == cid then
	CapSeahorsebcprice = 40
	CapSeahorsebcdestination = Boatvenore
	bcname = "Venore"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSeahorsebcprice .." gold?", 1)
	TalkState(cid, 94991)	

elseif msgcontains(msg, "ankrahmun") and npcHandler.focus == cid then
	CapSeahorsebcprice = 160
	CapSeahorsebcdestination = Boatankrahmun
	bcname = "Ankrahmun"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSeahorsebcprice .." gold?", 1)
	TalkState(cid, 94990)

elseif msgcontains(msg, "port hope") and npcHandler.focus == cid then
	CapSeahorsebcprice = 150
	CapSeahorsebcdestination = Boatporthope
	bcname = "Port Hope"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSeahorsebcprice .." gold?", 1)
	TalkState(cid, 94990)	
--End of Give Destination--
	

	
	
--System that does the job after confirm destination--
elseif GetTalkState(cid) == 94990 and msgcontains(msg, 'yes') and npcHandler.focus == cid then
	if (getTilePzInfo(pos) == FALSE) then
		if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
		doTeleportThing(cid, CapSeahorsebcdestination)
		doSendMagicEffect(CapSeahorsebcdestination, 10)
		npcHandler:say("Set the sails!", 1)
		TalkState(cid, 0)
		else
		npcHandler:say("You don't have enough money.", 1)
		TalkState(cid, 0)
		end
	else
	npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
	TalkState(cid, 0)	
	end
	
elseif GetTalkState(cid) == 94991 and msgcontains(msg, 'yes') and npcHandler.focus == cid then
	if (getTilePzInfo(pos) == FALSE) then
		if doPlayerRemoveMoney(cid, CapSeahorsebcprice) == TRUE then
		doTeleportThing(cid, CapSeahorsebcdestination)
		doSendMagicEffect(CapSeahorsebcdestination, 10)
		npcHandler:say("Set the sails!", 1)
		if(getPlayerStorageValue(cid, 250) == 1 and getPlayerStorageValue(cid, 253) <= 1) then
		setPlayerStorageValue(cid, 253, 1)
		end
		TalkState(cid, 0)
		else
		npcHandler:say("You don't have enough money.", 1)
		TalkState(cid, 0)
		end
	else
	npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
	TalkState(cid, 0)	
	end
--End of the System that does the job after confirm destination--
	
	
end		
    return 1
end


npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback)
npcHandler:addModule(FocusModule:new())
