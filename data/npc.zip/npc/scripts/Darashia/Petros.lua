dofile(getDataDir() .. 'global/greeting.lua')

local keywordHandler = KeywordHandler:new()
local npcHandler = NpcHandler:new(keywordHandler)
NpcSystem.parseParameters(npcHandler)



-- OTServ event handling functions start
function onCreatureAppear(cid)				npcHandler:onCreatureAppear(cid) end
function onCreatureDisappear(cid) 			npcHandler:onCreatureDisappear(cid) end
function onCreatureSay(cid, type, msg) 	npcHandler:onCreatureSay(cid, type, msg) end
function onThink() 						npcHandler:onThink() end


local shopModule = ShopModule:new()
npcHandler:addModule(shopModule)
 

keywordHandler:addKeyword({'name'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My name is Petros"})
keywordHandler:addKeyword({'job'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I take along people to Venore, Port Hope and Ankrahmun."})
keywordHandler:addKeyword({'ghost'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Oh, I don't believe in ghosts."})
keywordHandler:addKeyword({'ship'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My boat is ready to bring you to Venore, Port Hope or Ankrahmun."})
keywordHandler:addKeyword({'boat'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My boat is ready to bring you to Venore, Port Hope or Ankrahmun."})

function creatureSayCallback(cid, type, msg) msg = string.lower(msg)
pos = getPlayerPosition(cid)
	if(npcHandler.busyState ~= 0) and (npcHandler.focus ~= cid) then
		--Travel in hurry--
		if msgcontains(msg, "bring me to venore") then
			Petrosbcprice = 60
			Petrosbcdestination = Boatvenore
			bcname = "Venore"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, Petrosbcprice) == TRUE then
				doTeleportThing(cid, Petrosbcdestination)
				doSendMagicEffect(Petrosbcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to ankrahmun") then
			Petrosbcprice = 100
			Petrosbcdestination = Boatankrahmun
			bcname = "Ankrahmun"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, Petrosbcprice) == TRUE then
				doTeleportThing(cid, Petrosbcdestination)
				doSendMagicEffect(Petrosbcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to port hope") then
			Petrosbcprice = 180
			Petrosbcdestination = Boatporthope
			bcname = "Port Hope"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, Petrosbcprice) == TRUE then
				doTeleportThing(cid, Petrosbcdestination)
				doSendMagicEffect(Petrosbcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		--End of Travel in hurry--
		end
	end
	if(npcHandler.focus ~= cid) then
		return false
	end

--Give Destination--
if msgcontains(msg, 'venore') and npcHandler.focus == cid then
	Petrosbcprice = 60
	Petrosbcdestination = Boatvenore
	bcname = "Venore"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. Petrosbcprice .." gold?", 1)
	TalkState(cid, 94988)
	
elseif msgcontains(msg, "ankrahmun") and npcHandler.focus == cid then
	Petrosbcprice = 100
	Petrosbcdestination = Boatankrahmun
	bcname = "Ankrahmun"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. Petrosbcprice .." gold?", 1)
	TalkState(cid, 94988)
	
elseif msgcontains(msg, "port hope") and npcHandler.focus == cid then
	Petrosbcprice = 180
	Petrosbcdestination = Boatporthope
	bcname = "Port Hope"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. Petrosbcprice .." gold?", 1)
--End of Give Destination--
	

	
	
--System that does the job after confirm destination--
elseif GetTalkState(cid) == 94988 and msgcontains(msg, 'yes') and npcHandler.focus == cid then
	if (getTilePzInfo(pos) == FALSE) then
		if doPlayerRemoveMoney(cid, Petrosbcprice) == TRUE then
		doTeleportThing(cid, Petrosbcdestination)
		doSendMagicEffect(Petrosbcdestination, 10)
		npcHandler:say("Set the sails!", 1)
		TalkState(cid, 0)
		else
		npcHandler:say("You don't have enough money.", 1)
		TalkState(cid, 0)
		end
	else
	npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
	TalkState(cid, 0)	
	end
--End of the System that does the job after confirm destination--
	
	
end		
    return 1
end


npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback)
npcHandler:addModule(FocusModule:new())
