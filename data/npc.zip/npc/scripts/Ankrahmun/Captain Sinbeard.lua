dofile(getDataDir() .. 'global/greeting.lua')

local keywordHandler = KeywordHandler:new()
local npcHandler = NpcHandler:new(keywordHandler)
NpcSystem.parseParameters(npcHandler)



-- OTServ event handling functions start
function onCreatureAppear(cid)				npcHandler:onCreatureAppear(cid) end
function onCreatureDisappear(cid) 			npcHandler:onCreatureDisappear(cid) end
function onCreatureSay(cid, type, msg) 	npcHandler:onCreatureSay(cid, type, msg) end
function onThink() 						npcHandler:onThink() end

function greetCallback(cid)
	if getPlayerSex(cid) == 1 then
	npcHandler:setMessage(MESSAGE_GREET, "Welcome on board, Sir ".. getPlayerName(cid) ..".")
	return true
	else
	npcHandler:setMessage(MESSAGE_GREET, "Welcome on board, Madam ".. getPlayerName(cid) ..".")
	return true
	end	
end	
npcHandler:setCallback(CALLBACK_GREET, greetCallback)

local shopModule = ShopModule:new()
npcHandler:addModule(shopModule)
 

keywordHandler:addKeyword({'name'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I am known all over the world as Captain Sinbeard"})
keywordHandler:addKeyword({'job'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I am the captain of this sailing-ship."})
keywordHandler:addKeyword({'captain'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I am the captain of this sailing-ship."})
keywordHandler:addKeyword({'ship'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My ship is the fastest in the whole world."})
keywordHandler:addKeyword({'line'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My ship is the fastest in the whole world."})
keywordHandler:addKeyword({'company'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My ship is the fastest in the whole world."})
keywordHandler:addKeyword({'tibia'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "My ship is the fastest in the whole world."})
keywordHandler:addKeyword({'good'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "We can transport everything you want."})
keywordHandler:addKeyword({'passanger'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "We would like to welcome you on board."})
keywordHandler:addKeyword({'trip'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Darashia, Venore, Port Hope or Edron?"})
keywordHandler:addKeyword({'route'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Darashia, Venore, Port Hope or Edron?"})
keywordHandler:addKeyword({'passage'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Darashia, Venore, Port Hope or Edron?"})
keywordHandler:addKeyword({'town'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Darashia, Venore, Port Hope or Edron?"})
keywordHandler:addKeyword({'destination'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Darashia, Venore, Port Hope or Edron?"})
keywordHandler:addKeyword({'sail'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Darashia, Venore, Port Hope or Edron?"})
keywordHandler:addKeyword({'go'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "Where do you want to go? To Darashia, Venore, Port Hope or Edron?"})
keywordHandler:addKeyword({'thais'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm sorry but my ship does not currently service that port."})
keywordHandler:addKeyword({'carlin'}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm sorry but my ship does not currently service that port."})
keywordHandler:addKeyword({"ab'dendriel"}, StdModule.say, {npcHandler = npcHandler, onlyFocus = true, text = "I'm sorry but my ship does not currently service that port."})


function creatureSayCallback(cid, type, msg) msg = string.lower(msg)
pos = getPlayerPosition(cid)
	if(npcHandler.busyState ~= 0) and (npcHandler.focus ~= cid) then
		--Travel in hurry--
		if msgcontains(msg, "bring me to darashia") then
			CapSinbeardbcprice = 100
			CapSinbeardbcdestination = Boatdarashia
			bcname = "Darashia"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSinbeardbcprice) == TRUE then
				doTeleportThing(cid, CapSinbeardbcdestination)
				doSendMagicEffect(CapSinbeardbcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to edron") then
			CapSinbeardbcprice = 160
			CapSinbeardbcdestination = Boatedron
			bcname = "Edron"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSinbeardbcprice) == TRUE then
				doTeleportThing(cid, CapSinbeardbcdestination)
				doSendMagicEffect(CapSinbeardbcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to venore") then
			CapSinbeardbcprice = 150
			CapSinbeardbcdestination = Boatvenore
			bcname = "Venore"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSinbeardbcprice) == TRUE then
				doTeleportThing(cid, CapSinbeardbcdestination)
				doSendMagicEffect(CapSinbeardbcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		elseif msgcontains(msg, "bring me to port hope") then
			CapSinbeardbcprice = 80
			CapSinbeardbcdestination = Boatporthope
			bcname = "Port Hope"
			if (getTilePzInfo(pos) == FALSE) then
				if doPlayerRemoveMoney(cid, CapSinbeardbcprice) == TRUE then
				doTeleportThing(cid, CapSinbeardbcdestination)
				doSendMagicEffect(CapSinbeardbcdestination, 10)
				npcHandler:say("Set the sails!", 1)
				TalkState(cid, 0)
				else
				npcHandler:say("You don't have enough money.", 1)
				TalkState(cid, 0)
				end
			else
			npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
			TalkState(cid, 0)	
			end
		--End of Travel in hurry--
		end
	end
	
	if(npcHandler.focus ~= cid) then
		return false
	end
	
--Give Destination--
if msgcontains(msg, 'darashia') and npcHandler.focus == cid then
	CapSinbeardbcprice = 100
	CapSinbeardbcdestination = Boatdarashia
	bcname = "Darashia"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSinbeardbcprice .." gold?", 1)
	TalkState(cid, 94985)
	
elseif msgcontains(msg, "edron") and npcHandler.focus == cid then
	CapSinbeardbcprice = 160
	CapSinbeardbcdestination = Boatedron
	bcname = "Edron"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSinbeardbcprice .." gold?", 1)
	TalkState(cid, 94985)

elseif msgcontains(msg, "venore") and npcHandler.focus == cid then
	CapSinbeardbcprice = 150
	CapSinbeardbcdestination = Boatvenore
	bcname = "Venore"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSinbeardbcprice .." gold?", 1)
	TalkState(cid, 94985)
	
elseif msgcontains(msg, "port hope") and npcHandler.focus == cid then
	CapSinbeardbcprice = 80
	CapSinbeardbcdestination = Boatporthope
	bcname = "Port Hope"
	npcHandler:say("Do you seek a passage to ".. bcname .." for ".. CapSinbeardbcprice .." gold?", 1)
	TalkState(cid, 94985)
--End of Give Destination--
	

	
	
--System that does the job after confirm destination--
elseif GetTalkState(cid) == 94985 and msgcontains(msg, 'yes') and npcHandler.focus == cid then
	if (getTilePzInfo(pos) == FALSE) then
		if doPlayerRemoveMoney(cid, CapSinbeardbcprice) == TRUE then
		doTeleportThing(cid, CapSinbeardbcdestination)
		doSendMagicEffect(CapSinbeardbcdestination, 10)
		npcHandler:say("Set the sails!", 1)
		TalkState(cid, 0)
		else
		npcHandler:say("You don't have enough money.", 1)
		TalkState(cid, 0)
		end
	else
	npcHandler:say("If you want to travel with the boat you have to stand in it! else you'll just fall off!", 1)
	TalkState(cid, 0)	
	end
--End of the System that does the job after confirm destination--
	
	
end		
    return 1
end


npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback)
npcHandler:addModule(FocusModule:new())
